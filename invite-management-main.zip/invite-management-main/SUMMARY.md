# Table of contents

## 🎉 Features

* [Introduction](README.md)
* [Main features ](features/main-features.md)
* [Utility features](features/utility-features.md)

## Commands

* [Slash Commands](commands/slash-commands.md)
* [Normal Commands](commands/normal-commands.md)
* [Context Menu commands](commands/context-menu-commands.md)

## 🔗 Links

* [Invite me](links/invite-me.md)
* [Support](links/support.md)
* [Bot lists](links/bot-lists.md)
