---
description: Join the official support server
---

# Support

* **`Invite Management Support`** - [https://discord.com/invite/fFt8U2hZRn](https://discord.com/invite/fFt8U2hZRn)
* **`Short link`** - [https://dsc.gg/invitesupport](https://dsc.gg/invitesupport)

{% embed url="https://discord.com/invite/fFt8U2hZRn" %}
Support server
{% endembed %}
